# 🔗 آموزش n8n به فارسی | از صفر تا اتوماسیون حرفه‌ای

آموزش کامل و پروژه‌محور **n8n** (ابزار اتوماسیون workflow متن‌باز) به زبان فارسی — نوشته‌ی [محمدرضا](https://github.com/mdr702)، مدرس پایتون و اتوماسیون.

![n8n](https://img.shields.io/badge/n8n-Automation-ea4b71?style=flat-square)
![Level](https://img.shields.io/badge/level-beginner→advanced-blue?style=flat-square)
![Language](https://img.shields.io/badge/lang-فارسی-green?style=flat-square)
![License](https://img.shields.io/badge/license-MIT-lightgrey?style=flat-square)

## 📌 این دوره برای کیه؟

- کسانی که می‌خوان کارهای تکراری (ایمیل، اکسل، تلگرام، دیتابیس، API) رو خودکار کنن، بدون نوشتن کد زیاد
- برنامه‌نویس‌هایی که می‌خوان workflow‌های پیچیده‌تر با کد (Function Node) بسازن
- کسب‌وکارهایی که دنبال جایگزین متن‌باز و رایگان برای Zapier/Make هستن

## 🗂 فهرست مطالب

| # | فصل | توضیح |
|---|------|-------|
| 01 | [مقدمه و نصب n8n](./01-intro) | آشنایی با n8n، نصب لوکال (Docker) و نسخه‌ی Cloud |
| 02 | [مفاهیم پایه و Nodeها](./02-nodes-basics) | Node، Connection، Execution، Data Structure |
| 03 | [Triggerها](./03-triggers) | Manual, Schedule, Webhook, App Triggers |
| 04 | [کار با HTTP و APIها](./04-http-api) | HTTP Request Node، Auth، پارس کردن JSON |
| 05 | [Webhookها](./05-webhooks) | ساخت Webhook، اتصال به فرم‌ها و سرویس‌های بیرونی |
| 06 | [پروژه‌های واقعی](./06-real-world-projects) | اتوماسیون تلگرام، ایمیل، گوگل‌شیت، هوش مصنوعی |

هر فصل شامل:
- 📄 توضیح مفهومی (`README.md`)
- 🧩 فایل `workflow.json` آماده‌ی Import در n8n
- 🖼 اسکرین‌شات از workflow در پوشه‌ی `assets/`

## 🚀 شروع سریع

```bash
# نصب n8n با Docker (پیشنهادی)
docker run -it --rm \
  --name n8n \
  -p 5678:5678 \
  -v n8n_data:/home/node/.n8n \
  docker.n8n.io/n8nio/n8n
```

بعد از اجرا، وارد `http://localhost:5678` بشو و طبق فصل ۱ جلو برو.

## 📥 نحوه‌ی Import کردن Workflowها

1. وارد پنل n8n بشو
2. از منو گزینه‌ی **Import from File** رو بزن
3. فایل `workflow.json` مربوط به هر فصل رو انتخاب کن

## 🤝 مشارکت

اگه پیشنهاد، اصلاح یا workflow جدیدی داری، خوشحال می‌شم Pull Request بفرستی یا Issue باز کنی.

## 📬 ارتباط با من

- وبسایت: [simatacksanweb.ir](https://simatacksanweb.ir)
- گیت‌هاب: [@mdr702](https://github.com/mdr702)

## 📄 لایسنس

این پروژه تحت لایسنس MIT منتشر شده — آزادانه استفاده، کپی و توسعه بدید.
